// Solves the interdiction problem on a SINGLE NETWOK with probabilities on links.  Aggregates all the nodes in S into node 0, aggregates all nodes in T to node1
// Any s-t link in the resulting network is broken to disallow a trivial solution (node 0 or 1 targeted and disabled).
// Nodes have random weights.  Weights of node 0, node 1 are set to 100 (Big M) to disallow nodes 0, 1 being targeted (trivial solution).
// finds min weight nodes to target so that in the resulting network all s-t paths, i.e., 0-1 paths, have probability no more than (1-alpha) (say 0.01).
//import ilog.concert.IloException;
// full optimization
import ilog.concert.IloException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;




public class Alg {

	static double pVal;
	static public int maxArcs = 15000;
		
	static public int numArcs;
	static public int numNodes;
		
	static Arc arcs[] = new Arc[maxArcs];
//-----------------------------------------------------------------------------------------------
public void generateGraph(String vfile1) throws IOException
{
	int num = 0;
	Random r = new Random();
	for(int i = 0; i < numNodes-1;++i)
		for(int j = i+1;j<numNodes;++j)
		{
			double x = r.nextDouble(); 
			if(x < pVal)
			{
			  if(num >= maxArcs)
				  Diagnostic.verror(2, num, maxArcs);
			  arcs[num] = new Arc();
			  arcs[num].from = i;
			  arcs[num].to = j;
			  arcs[num].prob = genProb();
			  ++num;
			}
		}
	numArcs = num;
	String towrite;
	OutPut.initFile(vfile1);
    towrite = numNodes+"\t"+numArcs+"\t1\t1\r\n";
    OutPut.writeOut(vfile1, towrite);
    towrite = "S\r\n0\r\n";
    OutPut.writeOut(vfile1, towrite);
    towrite = "T\r\n1\r\n";
    OutPut.writeOut(vfile1, towrite);
    for(int i=0;i<numArcs;++i)
    {
    	int node1 = arcs[i].from;
    	int node2 = arcs[i].to;
    	towrite = node1+"\t"+node2+"\t"+arcs[i].prob+"\r\n";
    	OutPut.writeOut(vfile1, towrite);
    }
    towrite = "END\r\n";
    OutPut.writeOut(vfile1, towrite);
}/*end_ generateGraph()*/
//--------------------------------------------------------------------------------------------------------------------------------
public double genProb()
{
	Random r = new Random();
	double x = r.nextDouble();
	if(x < 0.2)
		return(0.2);
	else if(x < 0.4)
		return(0.4);
	else if(x < 0.6)
		return(0.6);
	else if(x < 0.8)
		return(0.8);
	else
		return(0.999);
		
}/*end_genprob()*/
//-------------------------------------------------------------------------------------------------------------------------------
public void generateWeights(String vfile2) throws IOException
{
	String towrite;
	OutPut.initFile(vfile2);
	for(int i=0;i<numNodes;++i)
	{
		int xweight = randomWeight();
		towrite = xweight+"\r\n";
	    OutPut.writeOut(vfile2, towrite);
	}
	
}/*end_ generateWeights()*/
//--------------------------------------------------------------------------------------------------------------------------------
public static void main(String[] args) throws IloException, IOException  {
	
	Alg driver = new Alg();
				
	pVal = Double.parseDouble(args[0]);
	numNodes = Integer.parseInt(args[1]);
	System.out.println(" *** E-R graph generator: nodes "+numNodes+" link prob "+pVal+" ***\n");
	String vfile1 = "//cob-file.scheller.gatech.edu/profiles/profiles/vvenkate3/Documents/Desktop/Computational_Tests/VFRP17/ERgraphs/prob"+Integer.toString(numNodes)+".txt";
	String vfile2 = "//cob-file.scheller.gatech.edu/profiles/profiles/vvenkate3/Documents/Desktop/Computational_Tests/VFRP17/ERgraphs/weights"+Integer.toString(numNodes)+".txt";
	driver.generateGraph(vfile1);
	driver.generateWeights(vfile2);
	System.out.println(" numArcs "+numArcs);
	System.out.println("\n *** DONE ***");
	
}/* end_main() */
/*---------------------------------------------------------------------------------------------------------------------------------*/
public int randomWeight()
{
	Random r = new Random();
	double x = r.nextDouble();
	if(x < 0.2)
		return(1);
	else if(x < 0.4)
		return(2);
	else if(x < 0.6)
		return(3);
	else if(x < 0.8)
		return(4);
	else
		return(5);
	
}/*end_randomweight()*/
//----------------------------------------------------------------------------------------------------------------
}/* end_class */

