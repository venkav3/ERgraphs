import java.io.BufferedReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;



public class Diagnostic {
	static DecimalFormat decfor = new DecimalFormat("0.00");
	static DecimalFormat decfor2 = new DecimalFormat("0.0000");
	static final double EPS2 = 0.01;
	static public int maxNodes = 500;
	static String towrite;
   	static String outfile = "//cob-file.scheller.gatech.edu/profiles/vvenkate3/Documents/Desktop/Computational_Tests/output.txt";
	/*------------------------------------------------------------------------------------*/
    
   public static void verror(int icase, int val,int max)
    {
    	switch(icase){
    	case 1:
    		System.out.println("numNodes "+val+" > max "+max+" aborting\n");
    		break;
    	case 2:
    		System.out.println("numArcs "+val+" > max "+max+" aborting\n");
    		break;
    	case 3:
    		System.out.println("degree of node "+val+" > max "+max+" aborting\n");
    		break;
    	case 4:
    		System.out.println("node  "+val+" has neighbor "+max+" repeated in multiple links\n");
    		break;
    	case 5:
    		System.out.println("variables in constraint matrix "+val+" not equal to predicted, numvar "+max+"; aborting\n");
    		break;
    	case 6:
    		System.out.println("for node "+val+" discrepency between no.intra network neighbors measured and predicted; delta "+max+"; aborting\n");
    		break;
    	case 7:
    		System.out.println("for node "+val+" invalid network number "+max+"; aborting\n");
    		break;
    	case 8:
    		System.out.println("inew "+val+" numNodes effective "+max+"; aborting\n");
    		break;
    	case 9:
    		System.out.println("s-t path length "+val+" exceeds array size "+max+"; aborting\n");
    		break;
    	default:
    	}
    	System.exit(0);
    }/*end_verror()*/
 /*-------------------------------------------------------------------*/
   
}/*end-class*/
